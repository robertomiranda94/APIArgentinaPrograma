package com.portfolioRobertoMiranda.argentinaprograma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArgentinaprogramaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArgentinaprogramaApplication.class, args);
	}

}
